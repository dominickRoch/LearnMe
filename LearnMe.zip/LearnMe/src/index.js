const API_URL = 'http://localhost:"#colocarPorta# API"';

export async function getUsuarios() {
  const response = await fetch(`${URL}/usuarios`);
  const data = await response.json();
  return data;
}

export async function createUsuario(usuario) {
  const response = await fetch(`${URL}/usuarios`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(usuario)
  });
  return await response.json();
}



import React, { useState } from 'react';
import { createUsuario } from '#';

const CadastroUsuario = () => {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const usuario = { nome, email, senha };
    await createUsuario(usuario);
    alert('Usuário cadastrado com sucesso');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Nome"
        value={nome}
        onChange={(e) => setNome(e.target.value)}
        required
      />
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />
      <input
        type="password"
        placeholder="Senha"
        value={senha}
        onChange={(e) => setSenha(e.target.value)}
        required
      />
      <button type="submit">Cadastrar</button>
    </form>
  );
};

export default CadastroUsuario;




//Listagem de Requisitos

// Controle de Autenticação
export class AuthController {
  login(email, password) {
    // login
    console.log(`Logging in with email: ${email}`);
  }

  register(userData) {
    // novo usuário
    console.log('Registering user:', userData);
  }

  resetPassword(email) {
    // resetar a senha
    console.log(`Sending password reset to: ${email}`);
  }
}

// Perfil do Usuário

export class UserProfile {
  constructor(name, email, preferences) {
  this.name = name;
  this.email = email;
  this.preferences = preferences;
  }

  editProfile(profileData) {
    // editar perfil
    this.name = profileData.name;
    this.email = profileData.email;
    this.preferences = profileData.preferences;
    console.log('Profile updated:', this);
  }

  uploadProfilePicture(image) {
    // foto de perfil
    console.log('Profile picture uploaded:', image);
  }
}

// Conteudos da Biblioteca

export class ResourceLibrary {
  constructor() {
    this.resources = [];
  }

  searchResources(query) {
    // buscar recursos
    console.log(`Searching resources with query: ${query}`);
    return this.resources.filter(resource => resource.title.includes(query));
  }

  addToFavorites(resourceId) {
    // adicionar recurso aos favoritos
    console.log(`Added resource ${resourceId} to favorites`);
  }
}


// Progresso

export class ProgressTracker {
  constructor() {
    this.completedTasks = [];
    this.progress = 0;
  }

  trackProgress(taskId) {
    // atualizar o progresso do usuario
    this.completedTasks.push(taskId);
    this.progress = (this.completedTasks.length / 100) * 100;
    console.log(`Progress tracked. ${taskId} completed. Current progress: ${this.progress}%`);
  }

  getProgressSummary() {
    // retornar um resumo do progresso
    return {
      completedTasks: this.completedTasks,
      progress: this.progress
    };
  }
}

// Forum

export class CommunityForum {
  constructor() {
    this.topics = [];
  }

  createTopic(topicData) {
    // criar um novo tópico
    this.topics.push(topicData);
    console.log('Topic created:', topicData);
  }

  replyToTopic(topicId, replyData) {
    // responder a um tópico existente
    const topic = this.topics.find(t => t.id === topicId);
    if (topic) {
      topic.replies.push(replyData);
      console.log('Replied to topic:', replyData);
    }
  }
}

